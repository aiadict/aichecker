import{A as a,g as l}from"./config-BzGAZ4su.js";const d=20,h="ai-checker-floating-icon-host";let t=null,r=null;function u(){if(!t){t=document.createElement("div"),t.id=h,t.style.position="absolute",t.style.zIndex="2147483647",t.style.display="none",document.documentElement.appendChild(t);const e=t.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=`
      button {
        all: unset;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border-radius: 999px;
        background: #3d6fe0;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(0,0,0,0.25);
      }
      button:hover { background: #2c56c4; }
      button svg { width: 20px; height: 20px; display: block; }
    `;const i=document.createElement("button");i.type="button",i.innerHTML=`
      <svg viewBox="0 0 32 32">
        <rect x="6.5" y="19.4" width="14" height="2.4" rx="1.2" fill="#fff"/>
        <rect x="6.5" y="24.4" width="9" height="2.4" rx="1.2" fill="#fff" opacity="0.75"/>
        <circle cx="19.5" cy="12" r="6" fill="none" stroke="#fff" stroke-width="1.8"/>
        <line x1="23.7" y1="16.2" x2="27" y2="19.5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
      </svg>
    `,i.setAttribute("aria-label","Check selection for AI Checker"),e.appendChild(o),e.appendChild(i)}const n=t.shadowRoot.querySelector("button");return{host:t,button:n}}function c(){t&&(t.style.display="none")}function f(n,e){const{host:o,button:i}=u();document.documentElement.appendChild(o),o.style.top=`${window.scrollY+n.bottom+6}px`,o.style.left=`${window.scrollX+n.left}px`,o.style.display="block",i.onclick=s=>{s.preventDefault(),s.stopPropagation(),c(),chrome.runtime.sendMessage({type:"ai-checker/open-panel-with-selection",text:e,sourceUrl:window.location.href})}}async function p(){if(!(await l()).showFloatingIcon){c();return}const e=window.getSelection(),o=(e==null?void 0:e.toString().trim())??"";if(r&&clearTimeout(r),!e||e.isCollapsed||o.length<d){r=setTimeout(c,150);return}const s=e.getRangeAt(0).getBoundingClientRect();s.width===0&&s.height===0||f(s,o)}document.addEventListener("selectionchange",()=>{p().catch(()=>c())});document.addEventListener("mousedown",n=>{t&&!t.contains(n.target)&&c()});window.location.origin===a&&window.addEventListener("message",n=>{var e;n.origin===a&&((e=n.data)==null?void 0:e.type)==="ai-checker/auth-success"&&chrome.runtime.sendMessage({type:"ai-checker/store-auth-session",accessToken:n.data.accessToken,refreshToken:n.data.refreshToken})});
